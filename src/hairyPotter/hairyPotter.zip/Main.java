package hairyPotter;


public class Main
{
    public static void main(String [] args)
    {
        System.out.println("Welcome to the Game!");
        Frame startGame = new Frame();
  /*      startGame.setExtendedState(Frame.MAXIMIZED_BOTH);
        startGame.setUndecorated(true);
        startGame.setVisible(true);
        */
    }
}
    

